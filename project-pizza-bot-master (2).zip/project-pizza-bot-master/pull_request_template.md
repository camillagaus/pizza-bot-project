Link to my deployed project:

My reflections on how this week's project turned out:

Things I'd like to have clarified or explained in more detail:
